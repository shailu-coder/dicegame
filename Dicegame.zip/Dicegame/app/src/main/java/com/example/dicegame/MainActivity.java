package com.example.dicegame;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    ImageView iv_dice_p1, iv_dice_p2, iv_lives_p1, iv_lives_p2;
    TextView tv_player1, tv_player2;

    Random r;

    int livesp1, livesp2;
    int rolledp1, rolledp2;

    Animation animation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        r = new Random();

        animation= AnimationUtils.loadAnimation(this, R.anim.rotate);

        iv_dice_p1 = findViewById(R.id.iv_dice_p1);
        iv_dice_p2 = findViewById(R.id.iv_dice_p2);

        iv_lives_p1 = findViewById(R.id.iv_lives_p1);
        iv_lives_p2 = findViewById(R.id.iv_lives_p2);

        tv_player1 = findViewById(R.id.tv_player1);
        tv_player2= findViewById(R.id.tv_player2);

        tv_player1.setText("PLAYER 1 TURN!");
        tv_player2.setText("PLAYER 2 TURN!");

        livesp1= 6;
        livesp2=6;

        setDiceImage(livesp1, iv_lives_p1);
        setDiceImage(livesp2, iv_lives_p2);

        iv_dice_p1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rolledp1 = r.nextInt(6) + 1;
                setDiceImage(rolledp1, iv_dice_p1);
                iv_dice_p1.startAnimation(animation);

                if(rolledp2 != 0){
                    tv_player1.setText("PLAYER 1 ROLL!");
                    tv_player2.setText("PLAYER 2 ROLL!");

                    //calculate the winner
                    if(rolledp1>rolledp2){
                        livesp2--;
                        setDiceImage(livesp2, iv_lives_p2);

                        Toast.makeText(MainActivity.this, "Player 1 wins!", Toast.LENGTH_SHORT).show();
                    }

                    if(rolledp2>rolledp1){
                        livesp1--;
                        setDiceImage(livesp1, iv_lives_p1);
                        Toast.makeText(MainActivity.this, "Player 2 wins!", Toast.LENGTH_SHORT).show();
                    }

                    if(rolledp1==rolledp2){
                        Toast.makeText(MainActivity.this, "Draw!", Toast.LENGTH_SHORT).show();
                    }

                    //check for player with 0 lives left

                    rolledp1=0;
                    rolledp2=0;

                    iv_dice_p1.setEnabled(true);
                    iv_dice_p2.setEnabled(true);

                    checkEndGame();

                }else{
                    tv_player1.setText("PLAYER 1 ROLLED!");
                    iv_dice_p1.setEnabled(false);
                }
            }
        });

        iv_dice_p2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rolledp2= r.nextInt(6) + 1;
                setDiceImage(rolledp2, iv_dice_p2);
                iv_dice_p2.startAnimation(animation);


                if(rolledp1 != 0){
                    tv_player1.setText("PLAYER 1 ROLL!");
                    tv_player2.setText("PLAYER 2 ROLL!");

                    if(rolledp1>rolledp2){
                        livesp2--;
                        setDiceImage(livesp2, iv_lives_p2);

                        Toast.makeText(MainActivity.this, "Player 1 wins!", Toast.LENGTH_SHORT).show();
                    }
                    if(rolledp2>rolledp1){
                        livesp1--;
                        setDiceImage(livesp1, iv_lives_p1);

                        Toast.makeText(MainActivity.this, "Player 2 wins!", Toast.LENGTH_SHORT).show();
                    }

                    if(rolledp1==rolledp2){
                        Toast.makeText(MainActivity.this, "Draw!", Toast.LENGTH_SHORT).show();
                    }


                    rolledp1=0;
                    rolledp2=0;

                    iv_dice_p1.setEnabled(true);
                    iv_dice_p2.setEnabled(true);

                    checkEndGame();

                }else{
                    tv_player2.setText("PLAYER 2 ROLLED!");
                    iv_dice_p2.setEnabled(false);
                }
            }
        });
    }

    private void setDiceImage(int dice, ImageView image){
        switch (dice){
            case 1:
                image.setImageResource(R.drawable.dice1);
                break;
            case 2:
                image.setImageResource(R.drawable.dice2);
                break;
            case 3:
                image.setImageResource(R.drawable.dice3);
                break;
            case 4:
                image.setImageResource(R.drawable.dice4);
                break;
            case 5:
                image.setImageResource(R.drawable.dice5);
                break;
            case 6:
                image.setImageResource(R.drawable.dice6);
                break;
            default:
                image.setImageResource(R.drawable.dice0);
        }
    }

    private void checkEndGame(){
        if (livesp1 ==0 || livesp2==0){
            iv_dice_p1.setEnabled(false);
            iv_dice_p2.setEnabled(false);

            String text= "";
            if(livesp1 !=0){
                text="Game Over! Winner Player 1!";
            }

            if(livesp2 !=0){
                text="Game Over! Winner Player 2!";
            }

            AlertDialog.Builder alertDialogBuidler = new AlertDialog.Builder(this);
            alertDialogBuidler.setCancelable(false);
            alertDialogBuidler.setMessage(text);
            alertDialogBuidler.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    finish();
                }
            });
            AlertDialog alertDialog = alertDialogBuidler.create();
            alertDialog.show();
        }
    }
}
